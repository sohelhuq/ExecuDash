export const firebaseConfig = {
  "projectId": "studio-9169148148-e27da",
  "appId": "1:1030857823933:web:450abbb78d5dca9b9509d4",
  "apiKey": "AIzaSyBSvFAyZJJ_oP4ZYMpOcPZHfDDV1VVDm84",
  "authDomain": "studio-9169148148-e27da.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "1030857823933"
};

